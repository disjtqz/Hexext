#pragma once

bool perform_late_if_inversion(ctree_transform_state_t* cfunc);
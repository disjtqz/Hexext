#pragma once

namespace cs::bitsim {
	template<typename SimulationTraits>  
	struct bitsim_tmpl_t {
#include "bitsim_impl.hpp"

	};
}

#pragma once
/*
	This is one of my favorite little tricks that I've implemented this plug-in. 
	It seems that the role of field is maintained throughout all transformation passes as long as the call is 
	never eliminated by the optimizer. This lets us tag function calls with custom information as the 
	decompiler will not object to a role that it does not recognize. We can use this field to do a variety of things,
	I have a lot of ideas about this, but primarily we can use it to implement custom roles 
	that allow us to match up intrinsic function calls without having to do string comparisons.
*/
enum class exrole_t : uint8_t {
#define FCLASS(name)		name,
#include "exrole_exmacro.hpp"

#undef FCLASS
	none
};
/*
	This iterates over all instructions that call intrinsic functions and tags them with their proper extended roles.
*/
void tag_helpers_with_exrole(mbl_array_t* mba);

/*
	Returns the function call instruction intrinsic role if it is a call instruction. Otherwise it will return the none role.
*/
exrole_t get_instruction_exrole(minsn_t* insn);

struct exrole_call_binary_t {
	mop_t* first;
	mop_t* second;
};

static inline exrole_call_binary_t extract_binary_exrole(minsn_t* insn, exrole_t role) {

	exrole_t r = get_instruction_exrole(insn);
	
	if (r != role) {
		return { nullptr, nullptr };
	}
	cs_assert(insn->d.f->args.size() == 2);

	return { &insn->d.f->args[0], &insn->d.f->args[1] };

}

#include "../cs_core.hpp"
#include <hexrays.hpp>
#include "../micro_on_70.hpp"
#include "../hexutils/hexutils.hpp"
#include "exrole.hpp"
#include "exrole_internal.hpp"

static cs_funcclass_tree_t g_role_tree{};

static bool g_did_init_tree = false;

constexpr auto funcset_tzcnt = make_funcset(exrole_t::tzcnt, 
	"_BitScanForward", 
	"_BitScanForward64",
	"_tzcnt_u32", 
	"_tzcnt_u64"
);


constexpr auto funcset_popcnt = make_funcset(exrole_t::popcnt,
	"__popcnt",
	"__popcnt16"
	);

constexpr auto funcset_lzcnt = make_funcset(exrole_t::lzcnt,
	"_BitScanForward",
	"_BitScanForward64",
	"__lzcnt",
	"__lzcnt16",
	"__clz"
	);

constexpr auto funcset_prefetch = make_funcset(exrole_t::pld,
	"__pld",
	"__pli",
	"_mm_prefetch");

constexpr auto funcset_rbit = make_funcset(exrole_t::rbit,
	"__rbit");

constexpr auto funset_byteshr128 = make_funcset(exrole_t::byteshr128,
	"_mm_srli_si128");

constexpr auto funcset_xor128 = make_funcset(exrole_t::xor128,
	"_mm_xor_si128",
	"_mm_xor_pd",
	"_mm_xor_ps");

CS_NOINLINE
static void do_initcheck() {
	if (g_did_init_tree)
		return;

	funcset_tzcnt.add_to_tree(g_role_tree);
	funcset_popcnt.add_to_tree(g_role_tree);
	funcset_lzcnt.add_to_tree(g_role_tree);
	funcset_prefetch.add_to_tree(g_role_tree);
	funcset_rbit.add_to_tree(g_role_tree);
	funset_byteshr128.add_to_tree(g_role_tree);
	funcset_xor128.add_to_tree(g_role_tree);
	g_did_init_tree = true;
}



static exrole_t generate_role_for_helper_name(const char* helper) {
	do_initcheck();
	//msg("%s\n", _name);
	unsigned length = strlen(helper);

	unsigned hashcode = cs::const_ops::hash_string(helper);

	cs_funcset_submit_t key;
	key.m_hashcode = hashcode;
	key.m_len = length;
	key.m_name = helper;
	auto iter = g_role_tree.find(key);

	if (iter != g_role_tree.end()) {
		return iter->second;
	}
	else {
		return exrole_t::none;
	}
}

constexpr unsigned EXROLE_MASK = 1 << 31;


static constexpr unsigned encode_exrole(exrole_t role) {
	return static_cast<unsigned>(role) | EXROLE_MASK;
}

static constexpr exrole_t decode_exrole(unsigned role) {
	if (!(role & EXROLE_MASK)) {
		return exrole_t::none;
	}
	else {
		role = role & ~EXROLE_MASK;
		std::underlying_type_t<exrole_t> _role = role;
		return *reinterpret_cast<exrole_t*>(&_role);
	}
}

struct traversal_traits_tag_exrole_t {
	static constexpr bool maintain_context_ptrs = false;

	static constexpr unsigned AUXSTACK_SIZE = 32;
	static constexpr bool may_term_flow = false;

};
/*
Traverse all instructions of the current function and tag them with their extended roles
*/
void tag_helpers_with_exrole(mbl_array_t* mba) {
	for (auto&& blk : forall_mblocks(mba)) {
		for (auto insn = blk->head; insn; insn = insn->next) {
			traverse_minsn< traversal_traits_tag_exrole_t>(insn, [](mop_t * mop) {

				if (mop->t != mop_d)
					return;

				minsn_t* inner = mop->d;
				if (inner->op() != m_call)
					return;

				if (inner->l.t != mop_h)
					return;

				exrole_t role = generate_role_for_helper_name(inner->l.helper);

				if (role == exrole_t::none)
					return;

				cs_assert(inner->d.t == mop_f);

				inner->d.f->role = (funcrole_t)encode_exrole(role);


			});

		}

	}
}

exrole_t get_instruction_exrole(minsn_t* insn) {
	cs_assert(insn);

	if (insn->op() != m_call || insn->l.t != mop_h)
		return exrole_t::none;

	
	cs_assert(insn->d.t == mop_f);
	return decode_exrole(insn->d.f->role);
}
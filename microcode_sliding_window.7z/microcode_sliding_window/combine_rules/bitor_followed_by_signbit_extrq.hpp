#pragma once

bool combine_signbit_shift_and_bitop(mblock_t* blk, minsn_t* insn);
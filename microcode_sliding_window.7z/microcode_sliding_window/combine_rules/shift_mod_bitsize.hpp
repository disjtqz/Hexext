#pragma once


bool combine_shift_mod_bitsize(mblock_t* blk, minsn_t* insn_);
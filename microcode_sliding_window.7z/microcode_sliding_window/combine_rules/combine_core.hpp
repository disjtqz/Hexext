#pragma once

void toggle_common_combination_rules(bool enabled);
void toggle_archspec_combination_rules(bool enabled);
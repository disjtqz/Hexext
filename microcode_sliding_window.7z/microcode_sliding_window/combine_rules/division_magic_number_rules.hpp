#pragma once

bool division_magic_num_rule_1(mblock_t* block, minsn_t* insn); 

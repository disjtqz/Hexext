#pragma once

bool combine_add_masked_one_conditional(mblock_t* block, minsn_t* insn);

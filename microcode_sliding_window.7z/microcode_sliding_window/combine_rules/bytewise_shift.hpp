#pragma once

bool combine_bytewise_shift(mblock_t* blk, minsn_t* insn);

bool combine_sign_shift_neg(mblock_t* blk, minsn_t* insn);
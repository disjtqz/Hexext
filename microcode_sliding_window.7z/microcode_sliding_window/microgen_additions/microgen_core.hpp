#pragma once

void toggle_microgen_additions(bool enabled);
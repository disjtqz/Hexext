#pragma once

bool resolve_thunk_function_address_x86_64(insn_t& insn);

bool resolve_thunk_function_address_arm32(insn_t& insn);
#pragma once
bool remove_nullsub_call(insn_t& cdg);
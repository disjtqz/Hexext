#pragma once

bool x86_is_simdreg(mreg_t mr);
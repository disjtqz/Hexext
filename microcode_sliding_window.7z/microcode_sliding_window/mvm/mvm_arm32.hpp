#pragma once


void mvm_arm32_init();
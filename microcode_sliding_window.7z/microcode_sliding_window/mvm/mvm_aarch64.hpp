#pragma once

void mvm_aarch64_init();